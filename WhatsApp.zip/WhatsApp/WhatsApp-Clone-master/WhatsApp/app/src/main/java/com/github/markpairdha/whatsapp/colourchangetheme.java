package com.github.markpairdha.whatsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class colourchangetheme extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_colourchangetheme);
        import android.graphics.Color;
        import android.os.Bundle;
        import android.view.Menu;
        import android.view.MenuItem;
        import android.widget.EditText;
        import androidx.appcompat.app.AppCompatActivity;
        import androidx.recyclerview.widget.LinearLayoutManager;
        import androidx.recyclerview.widget.RecyclerView;
        import java.util.ArrayList;
        import java.util.List;

        public class MainActivity extends AppCompatActivity {

            private RecyclerView recyclerView;
            private EditText messageInput;
            private ChatAdapter adapter;
            private List<String> messages = new ArrayList<>();

            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);

                recyclerView = findViewById(R.id.recycler_view);
                messageInput = findViewById(R.id.message_input);

                adapter = new ChatAdapter(messages);
                recyclerView.setAdapter(adapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(this));

                findViewById(R.id.send_button).setOnClickListener(v -> sendMessage());
            }

            private void sendMessage() {
                String message = messageInput.getText().toString().trim();
                if (!message.isEmpty()) {
                    messages.add(message);
                    adapter.notifyDataSetChanged();
                    messageInput.setText("");
                }
            }

            @Override
            public boolean onCreateOptionsMenu(Menu menu) {
                getMenuInflater().inflate(R.menu.main_menu, menu);
                return true;
            }

            @Override
            public boolean onOptionsItemSelected(MenuItem item) {
                if (item.getItemId() == R.id.change_color) {
                    changeBackgroundColor();
                    return true;
                }
                return super.onOptionsItemSelected(item);
            }

            private void changeBackgroundColor() {
                // Example: change to red color
                recyclerView.setBackgroundColor(Color.RED);
            }
        }

    }
}