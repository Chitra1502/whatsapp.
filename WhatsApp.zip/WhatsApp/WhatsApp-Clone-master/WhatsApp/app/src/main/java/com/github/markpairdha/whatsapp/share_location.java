package com.github.markpairdha.whatsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class share_location extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_location);

        import android.content.Intent;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

        public class MainActivity extends AppCompatActivity {

            private FusedLocationProviderClient fusedLocationProviderClient;

            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);

                fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

                Button shareLocationButton = findViewById(R.id.share_location_button);
                shareLocationButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        fetchAndShareLocation();
                    }
                });
            }

            private void fetchAndShareLocation() {
                if (isLocationEnabled()) {
                    fusedLocationProviderClient.getLastLocation()
                            .addOnSuccessListener(this, location -> {
                                if (location != null) {
                                    shareLocation(location);
                                }
                            });
                } else {
                    // Redirect user to settings to enable location
                    startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                }
            }

            private boolean isLocationEnabled() {
                // Check if location services are enabled
                // This is a basic check, a more detailed implementation can be added
                return true; // Placeholder, replace with actual check
            }

            private void shareLocation(Location location) {
                String uri = "geo:" + location.getLatitude() + "," + location.getLongitude();
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                startActivity(intent);
            }
        }

    }
}