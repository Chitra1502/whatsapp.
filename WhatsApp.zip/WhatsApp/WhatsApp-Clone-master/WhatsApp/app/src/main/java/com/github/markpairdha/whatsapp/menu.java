package com.github.markpairdha.whatsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            getMenuInflater().inflate(R.menu.main_menu, menu);
            return true;
        }

        @Override
        public boolean onOptionsItemSelected(MenuItem item) {
            switch (item.getItemId()) {
                case R.id.change_color:
                    changeBackgroundColor();
                    return true;
                // Add other cases for more menu items if needed
                default:
                    return super.onOptionsItemSelected(item);
            }
        }

        private void changeBackgroundColor() {
            // Example: change to red color
            recyclerView.setBackgroundColor(Color.RED);
        }

    }
}